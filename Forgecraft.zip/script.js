/* ============================================================
   FORGECRAFT v2 — interactions
   ============================================================ */
(function () {
  "use strict";

  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var clamp = function (v, a, b) { return Math.min(b, Math.max(a, v)); };
  var easeOut = function (t) { return 1 - Math.pow(1 - t, 3); };

  /* ---------- keyboard: generate realistic key rows ---------- */
  var keysHost = document.getElementById("mbKeys");
  if (keysHost) {
    // [keys in row, {index: extraFlexClass}]
    var rows = [
      { n: 13, cls: {} },                     // function row (short height via grid)
      { n: 13, cls: { 12: "half" } },         // numbers + backspace
      { n: 13, cls: { 0: "half" } },          // tab row
      { n: 12, cls: { 0: "half", 11: "half" } }, // caps + enter
      { n: 12, cls: { 0: "half", 11: "half" } }, // shift row
      { n: 7,  cls: { 3: "wide" } }           // ctrl/alt/space row
    ];
    rows.forEach(function (row) {
      var r = document.createElement("div");
      r.className = "k-row";
      for (var i = 0; i < row.n; i++) {
        var k = document.createElement("span");
        k.className = "key" + (row.cls[i] ? " " + row.cls[i] : "");
        r.appendChild(k);
      }
      keysHost.appendChild(r);
    });
  }

  /* ---------- intro: rise in, then lid opens ---------- */
  var mb = document.getElementById("mb");
  if (reduceMotion) {
    document.body.classList.add("loaded");
    mb.classList.add("open");
  } else {
    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        document.body.classList.add("loaded");
        setTimeout(function () { mb.classList.add("open"); }, 750);
      });
    });
  }

  /* ---------- screen: cycle through the website collection ---------- */
  var sites = Array.prototype.slice.call(document.querySelectorAll(".site"));
  var thumbs = Array.prototype.slice.call(document.querySelectorAll(".thumb"));
  var current = 0;
  function showSite(i) {
    current = i;
    sites.forEach(function (s, k) { s.classList.toggle("active", k === i); });
    thumbs.forEach(function (t, k) { t.classList.toggle("active", k === i); });
  }
  if (!reduceMotion && sites.length > 1) {
    setInterval(function () {
      if (document.hidden) return;
      showSite((current + 1) % sites.length);
    }, 4200);
  }

  /* ---------- laptop mouse parallax ---------- */
  var laptop3d = document.getElementById("laptop3d");
  if (laptop3d && !reduceMotion && window.matchMedia("(pointer: fine)").matches) {
    window.addEventListener("mousemove", function (e) {
      var ry = (e.clientX / window.innerWidth - 0.5) * 7;
      var rx = (e.clientY / window.innerHeight - 0.5) * -4;
      laptop3d.style.setProperty("--ry", ry + "deg");
      laptop3d.style.setProperty("--rx", rx + "deg");
    }, { passive: true });
  }

  /* ---------- marquee: duplicate content for seamless loop ---------- */
  var track = document.getElementById("marqueeTrack");
  if (track && !reduceMotion) {
    track.innerHTML += track.innerHTML;
  }

  /* ---------- dock menu ---------- */
  var burger = document.getElementById("dockBurger");
  var overlay = document.getElementById("menuOverlay");
  function closeMenu() {
    overlay.classList.remove("open");
    burger.setAttribute("aria-expanded", "false");
    document.body.style.overflow = "";
  }
  burger.addEventListener("click", function () {
    var open = overlay.classList.toggle("open");
    burger.setAttribute("aria-expanded", open ? "true" : "false");
    document.body.style.overflow = open ? "hidden" : "";
  });
  overlay.querySelectorAll("a").forEach(function (a) {
    a.addEventListener("click", closeMenu);
  });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && overlay.classList.contains("open")) closeMenu();
  });

  /* ---------- scroll-down button ---------- */
  var scrollDown = document.getElementById("scrollDown");
  if (scrollDown) {
    scrollDown.addEventListener("click", function () {
      document.getElementById("collection").scrollIntoView({ behavior: reduceMotion ? "auto" : "smooth" });
    });
  }

  /* ---------- reveal on scroll ---------- */
  var revealObserver = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (e.isIntersecting) {
        e.target.classList.add("in");
        revealObserver.unobserve(e.target);
      }
    });
  }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });
  document.querySelectorAll(".reveal").forEach(function (el) { revealObserver.observe(el); });

  /* ---------- stat counters ---------- */
  var statObserver = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (!e.isIntersecting) return;
      statObserver.unobserve(e.target);
      var el = e.target;
      var target = parseFloat(el.dataset.count);
      var suffix = el.dataset.suffix || "";
      if (reduceMotion) { el.textContent = target + suffix; return; }
      var t0 = null, dur = 1700;
      function step(ts) {
        if (!t0) t0 = ts;
        var p = easeOut(clamp((ts - t0) / dur, 0, 1));
        el.textContent = Math.round(target * p) + suffix;
        if (p < 1) requestAnimationFrame(step);
      }
      requestAnimationFrame(step);
    });
  }, { threshold: 0.6 });
  document.querySelectorAll(".stat-num").forEach(function (el) { statObserver.observe(el); });

  /* ---------- FAQ: animated open/close ---------- */
  document.querySelectorAll(".faq-item").forEach(function (item) {
    var summary = item.querySelector("summary");
    var body = item.querySelector(".faq-body");
    summary.addEventListener("click", function (e) {
      if (reduceMotion) return; // native behavior
      e.preventDefault();
      if (item.open) {
        body.style.height = body.scrollHeight + "px";
        requestAnimationFrame(function () {
          body.style.transition = "height 0.45s cubic-bezier(0.22,1,0.36,1)";
          body.style.height = "0px";
        });
        body.addEventListener("transitionend", function h() {
          item.open = false;
          body.style.cssText = "";
          body.removeEventListener("transitionend", h);
        });
      } else {
        item.open = true;
        var target = body.scrollHeight;
        body.style.height = "0px";
        requestAnimationFrame(function () {
          body.style.transition = "height 0.5s cubic-bezier(0.22,1,0.36,1)";
          body.style.height = target + "px";
        });
        body.addEventListener("transitionend", function h() {
          body.style.cssText = "";
          body.removeEventListener("transitionend", h);
        });
      }
    });
  });
})();
